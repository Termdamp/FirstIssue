import { useRef } from "react"
import { debounce } from "../utils/helpers"

export default function SearchBar({ value, onChange }) {
  const debouncedChange = useRef(
    debounce((val) => onChange(val), 400)
  ).current

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <span style={{
        position: 'absolute', left: '14px', top: '50%',
        transform: 'translateY(-50%)',
        color: '#334155', fontSize: '15px', pointerEvents: 'none',
      }}>⌕</span>
      <input
        type="text"
        defaultValue={value}
        onChange={(e) => debouncedChange(e.target.value)}
        placeholder="Search issues — try 'react', 'cli', 'documentation'..."
       style={{
          width: '100%',
          background: '#0A0A0A',
          border: '1px solid #27272A',
          borderRadius: '12px',
          padding: '16px 16px 16px 44px', /* Taller input */
          fontSize: '15px',
          color: '#FAFAFA',
          fontFamily: "'Inter', sans-serif",
          outline: 'none',
          transition: 'border-color 0.2s ease',
        }}
        onFocus={e => e.target.style.borderColor = '#FFFFFF'} /* Stark white focus */
        onBlur={e => e.target.style.borderColor = '#27272A'}
      />
    </div>
  )
}