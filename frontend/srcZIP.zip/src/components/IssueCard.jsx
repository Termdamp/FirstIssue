import { useState, useEffect } from "react"
import { timeAgo } from "../utils/helpers"
import { trackContribution } from "../services/github"

const LANGUAGE_COLORS = {
  JavaScript: "#f7df1e",
  TypeScript: "#3178c6",
  Python: "#3572A5",
  Rust: "#dea584",
  Go: "#00ADD8",
  Java: "#b07219",
  "C++": "#f34b7d",
  Ruby: "#701516",
}

function Modal({ issue, repoName, onClose, isBookmarked, onToggleBookmark }) {
  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [onClose])

  const createdDate = new Date(issue.created_at).toLocaleDateString("en-US", {
    year: "numeric", month: "long", day: "numeric"
  })

  const [repoData, setRepoData] = useState(null)

  useEffect(() => {
    if (!issue.repository_url) return
    fetch(`http://localhost:5000/api/repo?url=${encodeURIComponent(issue.repository_url)}`)
      .then(r => r.json())
      .then(setRepoData)
      .catch(() => {})
  }, [issue.repository_url])

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 100,
        background: 'rgba(0, 0, 0, 0.6)',
        backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '20px',
        animation: 'fadeIn 0.15s ease',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#0A0A0A',
          border: '1px solid #222222',
          borderRadius: '16px',
          width: '100%',
          maxWidth: '640px',
          maxHeight: '85vh',
          overflowY: 'scroll',
          padding: '32px',
          position: 'relative',
          animation: 'slideUp 0.2s ease',
          scrollbarWidth: 'thin',
          scrollbarColor: '#333333 #0A0A0A',
        }}
      >
        <style>{`
          @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
          @keyframes slideUp { from { transform: translateY(16px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
        `}</style>

        {/* Top action row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '12px', color: '#A1A1AA',
          }}>
            {repoName}
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => onToggleBookmark(issue)}
              style={{
                background: isBookmarked ? '#FFFFFF' : '#111111',
                border: `1px solid ${isBookmarked ? '#FFFFFF' : '#333333'}`,
                borderRadius: '8px',
                color: isBookmarked ? '#000000' : '#A1A1AA',
                width: '32px', height: '32px',
                cursor: 'pointer', fontSize: '14px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.15s',
              }}
            >
              {isBookmarked ? '★' : '☆'}
            </button>
            <button
              onClick={onClose}
              style={{
                background: '#111111', border: '1px solid #333333',
                borderRadius: '8px', color: '#A1A1AA',
                width: '32px', height: '32px',
                cursor: 'pointer', fontSize: '14px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >✕</button>
          </div>
        </div>

        {/* Title */}
        <h2 style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '22px', fontWeight: '600',
          color: '#FFFFFF', margin: '0 0 20px',
          lineHeight: '1.4', letterSpacing: '-0.02em'
        }}>
          {issue.title}
        </h2>

        {/* Meta row */}
        <div style={{
          display: 'flex', flexWrap: 'wrap', gap: '0',
          marginBottom: '20px',
          background: '#000000',
          borderRadius: '12px',
          border: '1px solid #222222',
          overflow: 'hidden',
        }}>
          {[
            { label: 'Opened', value: createdDate },
            { label: 'Comments', value: issue.comments },
            { label: 'State', value: issue.state, isState: true },
            ...(repoData ? [
              { label: 'Stars', value: `★ ${repoData.stargazers_count?.toLocaleString()}` },
              { label: 'Forks', value: `⑂ ${repoData.forks_count?.toLocaleString()}` },
            ] : []),
          ].map((item, i) => (
            <div key={i} style={{
              padding: '12px 16px',
              borderRight: '1px solid #222222',
              flex: '1',
              minWidth: '80px',
            }}>
              <div style={{
                fontSize: '11px', color: '#71717A',
                fontFamily: "'Inter', sans-serif", fontWeight: '500',
                marginBottom: '4px',
              }}>{item.label}</div>
              {item.isState ? (
                <span style={{
                  fontSize: '12px', color: '#000000',
                  background: '#FFFFFF',
                  padding: '2px 8px', borderRadius: '4px',
                  fontWeight: '600', fontFamily: "'Inter', sans-serif",
                }}>{item.value}</span>
              ) : (
                <div style={{ fontSize: '13px', color: '#FAFAFA' }}>{item.value}</div>
              )}
            </div>
          ))}
        </div>

        {/* Labels */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '24px' }}>
          {issue.labels?.map(label => (
            <span key={label.id} style={{
              fontSize: '12px', padding: '4px 10px', borderRadius: '6px',
              background: '#111111',
              color: '#A1A1AA',
              border: `1px solid #333333`,
              fontFamily: "'Inter', sans-serif", fontWeight: '500'
            }}>
              {label.name}
            </span>
          ))}
        </div>

        <div style={{ height: '1px', background: '#222222', marginBottom: '24px' }} />

        {/* Body */}
        {issue.body ? (
          <div style={{
            fontSize: '14px', color: '#A1A1AA',
            lineHeight: '1.8', marginBottom: '32px',
            whiteSpace: 'pre-wrap', wordBreak: 'break-word',
          }}>
            {issue.body}
          </div>
        ) : (
          <p style={{
            fontSize: '14px', color: '#71717A',
            marginBottom: '32px',
          }}>
            No description provided.
          </p>
        )}

        {/* CTA */}
        <a
          href={issue.html_url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => {
            const token = localStorage.getItem("fi_token")
            if (token) trackContribution(issue, token)
          }}
          style={{
            display: 'block', width: '100%', textAlign: 'center',
            background: '#FFFFFF',
            color: '#000000', fontWeight: '600',
            padding: '14px', borderRadius: '12px',
            textDecoration: 'none', fontSize: '15px',
            fontFamily: "'Inter', sans-serif",
            transition: 'opacity 0.2s',
            boxSizing: 'border-box',
          }}
          onMouseEnter={e => e.currentTarget.style.opacity = '0.9'}
          onMouseLeave={e => e.currentTarget.style.opacity = '1'}
        >
          View on GitHub ↗
        </a>
      </div>
    </div>
  )
}

export default function IssueCard({ issue, isBookmarked, onToggleBookmark }) {
  const [showModal, setShowModal] = useState(false)
  const repoName = issue.repository_url?.split("/repos/")[1] || "Unknown repo"

  const language = issue.labels?.find(l =>
    l.name.match(/^(javascript|typescript|python|rust|go|java|c\+\+|ruby)$/i)
  )?.name

  const difficultyLabel = issue.labels?.find(l =>
    ["good first issue", "help wanted", "beginner friendly", "easy"].includes(l.name.toLowerCase())
  )

  const createdDate = new Date(issue.created_at).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric"
  })

  return (
    <>
      <div
        onClick={() => setShowModal(true)}
        style={{
          background: '#0A0A0A', /* Very dark grey, almost black */
          border: '1px solid #222222', /* Ultra-thin border */
          borderRadius: '12px', /* Framer standard radius */
          padding: '24px',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          cursor: 'pointer',
          transition: 'background-color 0.2s ease, border-color 0.2s ease',
          position: 'relative',
        }}
        onMouseEnter={e => {
          e.currentTarget.style.backgroundColor = '#111111' /* Subtle lighten */
          e.currentTarget.style.borderColor = '#333333'
        }}
        onMouseLeave={e => {
          e.currentTarget.style.backgroundColor = '#0A0A0A'
          e.currentTarget.style.borderColor = '#222222'
        }}
      >
        {/* Bookmark button */}
        <button
          onClick={e => {
            e.stopPropagation()
            onToggleBookmark(issue)
          }}
          title={isBookmarked ? "Remove bookmark" : "Save issue"}
          style={{
            position: 'absolute', top: '14px', right: '14px',
            background: 'transparent', border: 'none',
            color: isBookmarked ? '#3b82f6' : '#334155',
            fontSize: '16px', cursor: 'pointer',
            padding: '2px',
            transition: 'color 0.15s, transform 0.15s',
          }}
          onMouseEnter={e => {
            e.currentTarget.style.color = '#3b82f6'
            e.currentTarget.style.transform = 'scale(1.2)'
          }}
          onMouseLeave={e => {
            e.currentTarget.style.color = isBookmarked ? '#3b82f6' : '#334155'
            e.currentTarget.style.transform = 'scale(1)'
          }}
        >
          {isBookmarked ? '★' : '☆'}
        </button>

        {/* Repo name */}
        <div style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: '11px', color: '#3b82f6',
          letterSpacing: '0.03em',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          paddingRight: '24px',
        }}>
          {repoName}
        </div>

        {/* Title */}
        <div style={{
          fontFamily: "'Syne', sans-serif",
          fontSize: '14px', fontWeight: '600',
          color: '#e2e8f0', lineHeight: '1.5',
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
          paddingRight: '8px',
        }}>
          {issue.title}
        </div>

        {/* Labels */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
          {language && (
            <span style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              fontSize: '11px', padding: '3px 9px', borderRadius: '20px',
              background: '#0a0e1a', color: '#94a3b8',
              border: '1px solid #1e2a3a',
              fontFamily: "'JetBrains Mono', monospace",
            }}>
              <span style={{
                width: '7px', height: '7px', borderRadius: '50%',
                background: LANGUAGE_COLORS[language] || '#64748b',
                flexShrink: 0,
              }} />
              {language}
            </span>
          )}
          {difficultyLabel && (
            <span style={{
              fontSize: '11px', padding: '3px 9px', borderRadius: '20px',
              background: 'rgba(74,222,128,0.08)', color: '#4ade80',
              border: '1px solid rgba(74,222,128,0.2)',
              fontFamily: "'JetBrains Mono', monospace",
            }}>
              {difficultyLabel.name}
            </span>
          )}
        </div>

        {/* Footer */}
        <div style={{
          display: 'flex', alignItems: 'center',
          justifyContent: 'space-between',
          marginTop: '6px', paddingTop: '12px',
          borderTop: '1px solid #1e2a3a',
          fontSize: '11px', color: '#475569',
          fontFamily: "'JetBrains Mono', monospace",
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <span style={{
              width: '6px', height: '6px', borderRadius: '50%',
              background: '#4ade80', flexShrink: 0,
            }} />
            open
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span>{issue.comments} comments</span>
            <span style={{ color: '#334155' }}>·</span>
            <span>{createdDate}</span>
          </span>
        </div>
      </div>

      {showModal && (
        <Modal
          issue={issue}
          repoName={repoName}
          onClose={() => setShowModal(false)}
          isBookmarked={isBookmarked}
          onToggleBookmark={onToggleBookmark}
        />
      )}
    </>
  )
}