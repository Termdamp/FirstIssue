export default function SkeletonCard() {
  return (
    <div style={{
      background: '#0A0A0A',
      border: '1px solid #222222',
      borderRadius: '12px',
      padding: '24px',
      display: 'flex',
      flexDirection: 'column',
      gap: '14px',
    }}>
      <div style={{ height: '12px', background: '#222222', borderRadius: '4px', width: '40%', animation: 'pulse 1.5s ease-in-out infinite' }} />
      <div style={{ height: '16px', background: '#222222', borderRadius: '4px', width: '90%', animation: 'pulse 1.5s ease-in-out infinite 0.1s' }} />
      <div style={{ height: '16px', background: '#222222', borderRadius: '4px', width: '70%', animation: 'pulse 1.5s ease-in-out infinite 0.2s' }} />
      <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
        <div style={{ height: '24px', background: '#222222', borderRadius: '6px', width: '70px', animation: 'pulse 1.5s ease-in-out infinite 0.3s' }} />
        <div style={{ height: '24px', background: '#222222', borderRadius: '6px', width: '90px', animation: 'pulse 1.5s ease-in-out infinite 0.4s' }} />
      </div>
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.7; }
        }
      `}</style>
    </div>
  )
}