export default function Navbar({ activeTab, onTabChange, bookmarkCount, user, onLogin, onLogout }) {
  return (
    <nav style={{
      borderBottom: '1px solid #222222',
      padding: '0 2rem',
      height: '64px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: 'rgba(0, 0, 0, 0.8)',
      backdropFilter: 'blur(16px)',
      WebkitBackdropFilter: 'blur(16px)',
    }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          width: '24px', height: '24px',
          background: '#FFFFFF', /* Pure white */
          borderRadius: '4px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '14px', fontWeight: '800',
          fontFamily: "'Inter', sans-serif",
          color: '#000000', /* Pure black text */
        }}>F</div>
        <span style={{
          fontFamily: "'Inter', sans-serif",
          fontWeight: '600',
          fontSize: '15px',
          letterSpacing: '-0.02em',
          color: '#FAFAFA',
        }}>FIRSTISSUE</span>
      </div>

      {/* Tabs & Links */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        {[
          { key: 'browse', label: 'Browse' },
          { key: 'saved', label: 'Saved', count: bookmarkCount },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => onTabChange(tab.key)}
            style={{
              background: activeTab === tab.key ? '#111111' : 'transparent',
              border: activeTab === tab.key ? '1px solid #333333' : '1px solid transparent',
              borderRadius: '8px',
              padding: '6px 14px',
              color: activeTab === tab.key ? '#FAFAFA' : '#A1A1AA',
              fontFamily: "'Inter', sans-serif",
              fontSize: '13px',
              fontWeight: '500',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'all 0.15s ease',
            }}
            onMouseEnter={e => { if (activeTab !== tab.key) e.currentTarget.style.color = '#FAFAFA' }}
            onMouseLeave={e => { if (activeTab !== tab.key) e.currentTarget.style.color = '#A1A1AA' }}
          >
            {tab.label}
            {tab.count > 0 && (
              <span style={{
                background: '#FFFFFF',
                color: '#000000',
                fontSize: '10px',
                padding: '2px 6px',
                borderRadius: '99px',
                fontWeight: '700',
              }}>
                {tab.count}
              </span>
            )}
          </button>
        ))}

        <div style={{ width: '1px', height: '16px', background: '#333333', margin: '0 8px' }} />

        <a
          href="https://github.com/Termdamp/FirstIssue"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            fontSize: '13px',
            color: '#A1A1AA',
            textDecoration: 'none',
            fontFamily: "'Inter', sans-serif",
            fontWeight: '500',
            padding: '6px 12px',
            transition: 'color 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.color = '#FAFAFA'}
          onMouseLeave={e => e.currentTarget.style.color = '#A1A1AA'}
        >
          GitHub ↗
        </a>
        
        <div style={{ width: '1px', height: '16px', background: '#333333', margin: '0 8px' }} />

        {/* Auth Section */}
        {user ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <img
              src={user.chosenAvatar?.seed
                ? `https://api.dicebear.com/7.x/${user.chosenAvatar.style}/svg?seed=${user.chosenAvatar.seed}`
                : user.githubAvatar}
              alt={user.username}
              onClick={() => onTabChange('profile')}
              style={{
                width: '32px', height: '32px', borderRadius: '50%',
                border: '1px solid #333333', cursor: 'pointer',
                transition: 'border-color 0.2s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#FFFFFF'}
              onMouseLeave={e => e.currentTarget.style.borderColor = '#333333'}
            />
            <button
              onClick={onLogout}
              style={{
                background: 'transparent', border: '1px solid #333333',
                borderRadius: '8px', color: '#A1A1AA',
                padding: '6px 12px', cursor: 'pointer',
                fontSize: '13px', fontFamily: "'Inter', sans-serif", fontWeight: '500',
                transition: 'all 0.2s'
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#FAFAFA'; e.currentTarget.style.color = '#FAFAFA'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#333333'; e.currentTarget.style.color = '#A1A1AA'; }}
            >
              Logout
            </button>
          </div>
        ) : (
          <button
            onClick={onLogin}
            style={{
              background: '#FFFFFF',
              border: '1px solid #FFFFFF',
              borderRadius: '8px',
              color: '#000000',
              padding: '8px 16px',
              cursor: 'pointer', fontSize: '13px',
              fontFamily: "'Inter', sans-serif",
              fontWeight: '600',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={e => e.currentTarget.style.opacity = '0.9'}
            onMouseLeave={e => e.currentTarget.style.opacity = '1'}
          >
            Sign in with GitHub
          </button>
        )}
      </div>
    </nav>
  )
}