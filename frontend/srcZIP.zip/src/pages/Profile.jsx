import { useState, useEffect } from "react"
import { useAuth } from "../hooks/useAuth.jsx"
import { fetchContributions } from "../services/github"

const BADGE_META = {
  first_look: {
    icon: "👀",
    label: "First Look",
    desc: "Viewed your first issue",
    color: "#3b82f6",
  },
  explorer: {
    icon: "🧭",
    label: "Explorer",
    desc: "Viewed 5 issues",
    color: "#8b5cf6",
  },
  curious: {
    icon: "🔍",
    label: "Curious",
    desc: "Viewed 10 issues",
    color: "#06b6d4",
  },
  contributor: {
    icon: "⚡",
    label: "Contributor",
    desc: "Viewed 25 issues",
    color: "#f59e0b",
  },
  dedicated: {
    icon: "🔥",
    label: "Dedicated",
    desc: "Viewed 50 issues",
    color: "#ef4444",
  },
  open_sourcerer: {
    icon: "🧙",
    label: "Open Sourcerer",
    desc: "Viewed 100 issues",
    color: "#4ade80",
  },
}

const ALL_BADGES = Object.keys(BADGE_META)

export default function Profile({ onBack, onEditAvatar }) {
  const { user } = useAuth()
  const [contributions, setContributions] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeSection, setActiveSection] = useState("overview")

  useEffect(() => {
    const token = localStorage.getItem("fi_token")
    if (!token) return
    fetchContributions(token)
      .then(data => {
        setContributions(Array.isArray(data) ? data : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  if (!user) return null

  const avatarUrl = user.chosenAvatar?.seed
    ? `https://api.dicebear.com/7.x/${user.chosenAvatar.style}/svg?seed=${user.chosenAvatar.seed}`
    : user.githubAvatar

  const earnedBadges = user.badges || []

  // Group contributions by language
  const languageMap = {}
  contributions.forEach(c => {
    if (c.language) {
      languageMap[c.language] = (languageMap[c.language] || 0) + 1
    }
  })
  const topLanguages = Object.entries(languageMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  return (
    <div style={{ minHeight: '100vh', background: '#0a0e1a', padding: '40px 24px 80px' }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>

        {/* Back button */}
        <button
          onClick={onBack}
          style={{
            background: 'transparent', border: 'none',
            color: '#475569', cursor: 'pointer',
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: '12px', marginBottom: '32px',
            padding: 0, display: 'flex', alignItems: 'center', gap: '6px',
          }}
        >
          ← back to feed
        </button>

        {/* Profile header */}
        <div style={{
          background: '#0A0A0A', /* Changed from #0f1623 */
          border: '1px solid #222222', /* Changed from #1e2a3a */
          borderRadius: '16px',
          padding: '32px', /* Slightly more padding */
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          gap: '24px',
          flexWrap: 'wrap',
        }}>
          <img
            src={avatarUrl}
            alt={user.username}
            style={{
              width: '80px', height: '80px',
              borderRadius: '50%',
              border: '3px solid #1e2a3a',
            }}
          />
          <div style={{ flex: 1 }}>
            <div style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: '22px', fontWeight: '700',
              color: '#f1f5f9', marginBottom: '4px',
            }}>
              {user.displayName || user.username}
            </div>
            <div style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: '12px', color: '#3b82f6',
              marginBottom: '8px',
            }}>
              @{user.username}
            </div>
            <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
              {[
                { label: 'Issues viewed', value: contributions.length },
                { label: 'Badges earned', value: earnedBadges.length },
                { label: 'Languages', value: topLanguages.length },
              ].map(stat => (
                <div key={stat.label}>
                  <span style={{
                    fontFamily: "'Syne', sans-serif",
                    fontSize: '18px', fontWeight: '700',
                    color: '#f1f5f9',
                  }}>{stat.value}</span>
                  <span style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: '11px', color: '#475569',
                    marginLeft: '6px',
                  }}>{stat.label}</span>
                </div>
              ))}
            </div>
            <button
              onClick={onEditAvatar}
              style={{
                marginTop: '12px',
                background: 'transparent',
                border: '1px solid #1e2a3a',
                borderRadius: '8px', padding: '6px 14px',
                color: '#64748b', cursor: 'pointer',
                fontSize: '12px',
                fontFamily: "'JetBrains Mono', monospace",
                transition: 'all 0.2s',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = '#3b82f6'
                e.currentTarget.style.color = '#3b82f6'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = '#1e2a3a'
                e.currentTarget.style.color = '#64748b'
              }}
            >
              edit avatar →
            </button>
          </div>
        </div>

        {/* Section tabs */}
        <div style={{
          display: 'flex', gap: '4px',
          marginBottom: '20px',
        }}>
          {['overview', 'badges', 'history'].map(section => (
            <button
              key={section}
              onClick={() => setActiveSection(section)}
              style={{
                background: activeSection === section ? '#111111' : 'transparent',
                border: activeSection === section ? '1px solid #333333' : '1px solid transparent',
                color: activeSection === section ? '#FFFFFF' : '#A1A1AA',
                padding: '7px 16px',
                color: activeSection === section ? '#e2e8f0' : '#475569',
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: '12px', cursor: 'pointer',
                textTransform: 'capitalize',
              }}
            >
              {section}
            </button>
          ))}
        </div>

        {/* Overview section */}
        {activeSection === "overview" && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>

            {/* Top languages */}
            <div style={{
              background: '#0f1623', border: '1px solid #1e2a3a',
              borderRadius: '12px', padding: '20px',
            }}>
              <div style={{
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: '11px', color: '#475569',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                marginBottom: '16px',
              }}>Top Languages</div>
              {topLanguages.length === 0 ? (
                <p style={{ fontSize: '12px', color: '#334155', fontFamily: "'JetBrains Mono', monospace" }}>
                  No data yet
                </p>
              ) : topLanguages.map(([lang, count]) => (
                <div key={lang} style={{ marginBottom: '10px' }}>
                  <div style={{
                    display: 'flex', justifyContent: 'space-between',
                    marginBottom: '4px',
                  }}>
                    <span style={{ fontSize: '12px', color: '#94a3b8', fontFamily: "'JetBrains Mono', monospace" }}>
                      {lang}
                    </span>
                    <span style={{ fontSize: '12px', color: '#475569', fontFamily: "'JetBrains Mono', monospace" }}>
                      {count}
                    </span>
                  </div>
                  <div style={{ height: '4px', background: '#222222', borderRadius: '2px' }}>
                    <div style={{
                      height: '100%',
                      width: `${(count / contributions.length) * 100}%`,
                      background: '#FFFFFF', /* Pure white fill */
                      borderRadius: '2px',
                      transition: 'width 0.5s ease',
                    }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Recent badges */}
            <div style={{
              background: '#0f1623', border: '1px solid #1e2a3a',
              borderRadius: '12px', padding: '20px',
            }}>
              <div style={{
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: '11px', color: '#475569',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                marginBottom: '16px',
              }}>Recent Badges</div>
              {earnedBadges.length === 0 ? (
                <p style={{ fontSize: '12px', color: '#334155', fontFamily: "'JetBrains Mono', monospace" }}>
                  View issues to earn badges
                </p>
              ) : earnedBadges.slice(0, 3).map(badge => {
                const meta = BADGE_META[badge]
                if (!meta) return null
                return (
                  <div key={badge} style={{
                    display: 'flex', alignItems: 'center', gap: '10px',
                    marginBottom: '10px',
                  }}>
                    <span style={{ fontSize: '20px' }}>{meta.icon}</span>
                    <div>
                      <div style={{ fontSize: '13px', color: '#e2e8f0', fontFamily: "'Syne', sans-serif", fontWeight: '600' }}>
                        {meta.label}
                      </div>
                      <div style={{ fontSize: '11px', color: '#475569', fontFamily: "'JetBrains Mono', monospace" }}>
                        {meta.desc}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Badges section */}
        {activeSection === "badges" && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
            gap: '12px',
          }}>
            {ALL_BADGES.map(badge => {
              const meta = BADGE_META[badge]
              const earned = earnedBadges.includes(badge)
              return (
                <div key={badge} style={{
                  background: '#0f1623',
                  border: `1px solid ${earned ? meta.color + '44' : '#1e2a3a'}`,
                  borderRadius: '12px', padding: '20px',
                  opacity: earned ? 1 : 0.4,
                  transition: 'all 0.2s',
                }}>
                  <div style={{ fontSize: '32px', marginBottom: '10px' }}>{meta.icon}</div>
                  <div style={{
                    fontFamily: "'Syne', sans-serif",
                    fontSize: '14px', fontWeight: '700',
                    color: earned ? meta.color : '#475569',
                    marginBottom: '4px',
                  }}>{meta.label}</div>
                  <div style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: '11px', color: '#475569',
                  }}>{meta.desc}</div>
                  {earned && (
                    <div style={{
                      marginTop: '10px',
                      fontSize: '10px',
                      fontFamily: "'JetBrains Mono', monospace",
                      color: meta.color,
                      background: meta.color + '11',
                      border: `1px solid ${meta.color}33`,
                      padding: '2px 8px', borderRadius: '20px',
                      display: 'inline-block',
                    }}>earned</div>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {/* History section */}
        {activeSection === "history" && (
          <div style={{
            background: '#0f1623', border: '1px solid #1e2a3a',
            borderRadius: '12px', overflow: 'hidden',
          }}>
            {loading ? (
              <div style={{
                padding: '40px', textAlign: 'center',
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: '12px', color: '#334155',
              }}>loading...</div>
            ) : contributions.length === 0 ? (
              <div style={{
                padding: '40px', textAlign: 'center',
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: '12px', color: '#334155',
              }}>No contributions yet — start exploring issues</div>
            ) : contributions.map((c, i) => (
              <div key={c._id} style={{
                padding: '16px 20px',
                borderBottom: i < contributions.length - 1 ? '1px solid #1e2a3a' : 'none',
                display: 'flex', justifyContent: 'space-between',
                alignItems: 'flex-start', gap: '12px',
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontFamily: "'Syne', sans-serif",
                    fontSize: '13px', fontWeight: '600',
                    color: '#e2e8f0', marginBottom: '4px',
                    display: '-webkit-box',
                    WebkitLineClamp: 1,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                  }}>{c.issueTitle}</div>
                  <div style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: '11px', color: '#3b82f6',
                  }}>{c.repoName}</div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px' }}>
                  {c.language && (
                    <span style={{
                      fontSize: '10px', padding: '2px 8px', borderRadius: '20px',
                      background: '#0a0e1a', color: '#64748b',
                      border: '1px solid #1e2a3a',
                      fontFamily: "'JetBrains Mono', monospace",
                    }}>{c.language}</span>
                  )}
                  <span style={{
                    fontSize: '10px', color: '#334155',
                    fontFamily: "'JetBrains Mono', monospace",
                  }}>
                    {new Date(c.viewedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}